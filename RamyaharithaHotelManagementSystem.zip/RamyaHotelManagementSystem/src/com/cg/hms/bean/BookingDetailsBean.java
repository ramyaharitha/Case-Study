package com.cg.hms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BookingDetailsBean 
{
	@Id
		@Column(name="booking_id")
    private int bookingId;
		@Column(name="room_id")
	private int roomId;
		@Column(name="user_id")
	private int userId;
		@Column(name="booked_from")
	private String bookedFrom;
		@Column(name="booked_to")
	private String bookedTo;
		@Column(name="no_of_adults")
	private int numberOfAdults;
		@Column(name="amount")
	private int amount;
		@Column(name="hotel_id")
	private int hotelId;
  
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getBookedFrom() {
		return bookedFrom;
	}
	public void setBookedFrom(String bookedFrom) {
		this.bookedFrom = bookedFrom;
	}
	public String getBookedTo() {
		return bookedTo;
	}
	public void setBookedTo(String bookedTo) {
		this.bookedTo = bookedTo;
	}
	public int getNumberOfAdults() {
		return numberOfAdults;
	}
	public void setNumberOfAdults(int numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	
	
	
	public BookingDetailsBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public BookingDetailsBean(int bookingId, int roomId, int userId,
			String bookedFrom, String bookedTo, int numberOfAdults, int amount,
			int hotelId) {
		super();
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.numberOfAdults = numberOfAdults;
		this.amount = amount;
		this.hotelId = hotelId;
	}
	
	
	
	@Override
	public String toString() {
		return "BookingDetailsBean [bookingId=" + bookingId + ", roomId="
				+ roomId + ", userId=" + userId + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", numberOfAdults="
				+ numberOfAdults + ", amount=" + amount + ", hotelId="
				+ hotelId + "]";
	} 
	
	
}
